public class VolumeOfCylinder {
    public static void main(String[] args) {
        double radius = 5;
        double height = 10;
        double pi = 3.14;

        double vol = pi * radius * radius * height;
        System.out.println("Volume of Cylinder = " + vol);

    }

}
