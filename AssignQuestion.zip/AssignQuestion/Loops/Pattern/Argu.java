public class Argu {
    public static void main(String[] args) {

        System.out.println(Add(2, 9));
    }

    static void Add(int x, int y) {
        int add = x + y;
        System.out.println("Add: " + add);
    }
}
