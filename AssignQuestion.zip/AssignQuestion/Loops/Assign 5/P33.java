//33) WAP to print Alphabets in reversing order.
public class P33 {
    public static void main(String[] args) {

        for (char ch = 90; ch >= 65; ch--) {
            System.out.print(ch + " ");
        }
    }
}
