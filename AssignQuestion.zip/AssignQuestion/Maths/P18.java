public class P18 {
    public static void main(String[] args) {
        float periOfRec, b = 30, h = 50;
        periOfRec = 2 * (b + h);
        float totRound = (periOfRec * 0.001f);
        System.out.println("Total Km he walk in a day: " + totRound + " km ");
    }
}
