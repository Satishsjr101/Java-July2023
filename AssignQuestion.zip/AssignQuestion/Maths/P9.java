public class P9 {
    //
    public static void main(String[] args) {
        float areaEqTr, side = 12;
        areaEqTr = (1.7320f / 4) * side * side; // root 3 =1.73
        System.out.println("Area of Eqiuilateral Triangle: " + areaEqTr);

    }
}
