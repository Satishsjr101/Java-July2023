public class P13 {
    public static void main(String[] args) {
        float areaOfTr = 184;
        double b;
        double h = 16;
        // (Area) = b*h/2
        b = (areaOfTr * 2) / h;
        System.out.println("Other side: " + b);

    }
}
