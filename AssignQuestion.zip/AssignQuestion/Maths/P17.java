public class P17 {
    public static void main(String[] args) {
        float periOfRec, b = 3, h = 2;
        periOfRec = 2 * (b + h);
        System.out.println("Ribbon required : " + periOfRec + " meter ");
    }
}
