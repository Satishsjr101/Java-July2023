public class P16 {
    public static void main(String[] args) {
        float areaOfRec, b = 7, h = 5;
        areaOfRec = (b * h) / 2;
        System.out.println("Area of Rectangle: " + areaOfRec + " meter sq");
    }
}
