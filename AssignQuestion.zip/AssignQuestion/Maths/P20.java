public class P20 {
    public static void main(String[] args) {
        // cuboid
        float volOfCuboid, l = 25, b = 10, h = 8;
        volOfCuboid = l * b * h;
        System.out.println("volOfCuboid " + volOfCuboid + " meter cube");
    }
}
