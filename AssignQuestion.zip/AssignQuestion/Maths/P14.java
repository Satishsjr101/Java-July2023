public class P14 {
    public static void main(String[] args) {
        float di = 46f, vd1 = 13, vd2 = 10, areaOfQuad;
        areaOfQuad = (di * (vd1 + vd2)) / 2;
        System.out.println("Area of Quadilateral: " + areaOfQuad);

    }
}
