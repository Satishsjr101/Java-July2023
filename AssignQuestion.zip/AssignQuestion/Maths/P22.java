public class P22 {
    public static void main(String[] args) {
        // cuboid
        float volOfCuboid, l = 50, b = 30, h = 2;
        volOfCuboid = l * b * h;
        System.out.println("volOfCuboid " + volOfCuboid + " meter cube");
    }
}
