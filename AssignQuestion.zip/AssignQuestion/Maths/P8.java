public class P8 {
    public static void main(String[] args) {
        // areaTr = 0.8m=0.8*100 = 80cm
        float areaTr = 80, b, h = 20;
        b = (areaTr * 2) / h; // ar=(h*b)/2
        System.out.println("Base Of Triangle: " + b + " cm");

    }
}
