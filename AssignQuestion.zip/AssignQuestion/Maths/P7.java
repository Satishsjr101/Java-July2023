public class P7 {
    public static void main(String[] args) {
        float areaTr = 500, b = 50f, h;
        h = (areaTr * 2) / b; // ar=(h*b)/2
        System.out.println("Heigth Of Triangles: " + h);

    }
}
