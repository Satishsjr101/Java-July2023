public class P10 {
    public static void main(String[] args) {
        float areaIsosTr, side = 15;
        areaIsosTr = (side * side) / 2; // A = ½ l2
        System.out.println("Area of Isosceles Right angled traingles: " + areaIsosTr);
    }
}
