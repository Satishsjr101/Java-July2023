//  Java Program to Increment All Element of an Array by One.
public class A8 {
    public static void main(String[] args) {
        int a[] = { 11, 666, 9999, 44444, 77777 };

        for (int i = 0; i < a.length; i++) {
            a[i]++;
            System.out.println(a[i]);
        }
    }
}
