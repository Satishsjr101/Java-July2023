public class P12 {
    public static void main(String[] args) {
        String day[] = { "Monday", "Tueasday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };

        for (int i = 0; i < day.length; i++) {
            System.out.println(day[i]);
        }
    }
}
