public class C1 {
    int a = 5;
    int b = 2;

    C1(int a, int b) {
        int add = a + b;
    }

    public static void main(String[] args) {
        C1 c1 = new C1(6, 9);
        System.out.println();

    }
}